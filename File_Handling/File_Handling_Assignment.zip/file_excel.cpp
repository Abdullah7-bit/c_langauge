#include<stdio.h>
int main(){
	FILE *s1;
	
	s1 = fopen("record.xls","w");
	
	int rollnum;
	char stdname[20];
	char grade[20];
	int fee;
	char branch[20];
	
	// input
	printf("\n Enter Student Roll Number: ");
	scanf("%d",&rollnum);
	
	printf("\n Enter Student Name: ");
	scanf("%s",&stdname);
	
	printf("\n Enter Class: ");
	scanf("%s",&grade);
	
	printf("\n Enter Fee: ");
	scanf("%d",&fee);
	
	printf("\n Enter Branch: ");
	scanf("%s",&branch);
	
	
	// output in excel
	fprintf(s1,"Roll # ");
	fprintf(s1,"\tStudent Name ");
	fprintf(s1,"\tClass ");
	fprintf(s1,"\tFee ");
	fprintf(s1,"\tBranch ");
	
	fprintf(s1,"\n");
	
	fprintf(s1,"%d",rollnum);
	fprintf(s1,"\t%s",stdname);
	fprintf(s1,"\t%s",grade);
	fprintf(s1,"\t%d",fee);
	fprintf(s1,"\t%s",branch);
		
	
	
}
